/* ============ FG ARTROMEDICA — interactions ============ */

// ---------- Sticky nav ----------
(() => {
  const nav = document.getElementById('nav');
  const onScroll = () => {
    if (window.scrollY > 24) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });
})();

// ---------- Catalog filter ----------
(() => {
  const grid = document.getElementById('catalog-grid');
  if (!grid) return;
  const chips = document.querySelectorAll('#filters .chip');
  const cards = grid.querySelectorAll('.cat-card');

  // Update counts
  const counts = { all: cards.length };
  cards.forEach(c => {
    const cat = c.dataset.cat;
    counts[cat] = (counts[cat] || 0) + 1;
  });
  document.querySelectorAll('[data-count]').forEach(el => {
    const k = el.getAttribute('data-count');
    el.textContent = ' · ' + (counts[k] || 0);
  });

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const f = chip.dataset.filter;
      cards.forEach(card => {
        const show = f === 'all' || card.dataset.cat === f;
        card.style.display = show ? '' : 'none';
      });
    });
  });
})();

// ---------- Scroll reveal ----------
(() => {
  const els = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) {
    els.forEach(el => el.classList.add('in'));
    return;
  }
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0, rootMargin: '0px 0px -80px 0px' });
  els.forEach(el => io.observe(el));

  // Fallback: if for any reason an element stays hidden after page load + 2s, reveal it.
  setTimeout(() => {
    els.forEach(el => {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight + 200) el.classList.add('in');
    });
  }, 2500);
})();

// ---------- Form handler (demo) ----------
(() => {
  const form = document.getElementById('contact-form');
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = form.querySelector('.btn-submit');
    const original = btn.innerHTML;
    btn.innerHTML = '✓ Solicitud enviada';
    btn.style.background = '#10A56C';
    btn.style.color = '#fff';
    btn.disabled = true;
    setTimeout(() => {
      btn.innerHTML = original;
      btn.style.background = '';
      btn.style.color = '';
      btn.disabled = false;
      form.reset();
    }, 2800);
  });
})();

// ---------- Smooth scroll for nav anchors (offset for sticky nav) ----------
(() => {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const href = a.getAttribute('href');
      if (href.length <= 1) return;
      const t = document.querySelector(href);
      if (!t) return;
      e.preventDefault();
      const offset = 70;
      const y = t.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    });
  });
})();

// ---------- Mobile nav ----------
(() => {
  const btn = document.getElementById('mobile-toggle');
  const links = document.querySelector('.nav-links');
  if (!btn || !links) return;
  btn.addEventListener('click', () => {
    const open = links.style.display === 'flex';
    if (open) {
      links.style.display = '';
    } else {
      links.style.display = 'flex';
      links.style.position = 'absolute';
      links.style.top = '100%';
      links.style.left = '16px';
      links.style.right = '16px';
      links.style.background = '#fff';
      links.style.flexDirection = 'column';
      links.style.padding = '12px';
      links.style.borderRadius = '14px';
      links.style.boxShadow = '0 12px 32px rgba(11, 31, 63, 0.18)';
      links.style.border = '1px solid var(--c-line)';
      links.style.marginTop = '8px';
    }
  });
})();

// ============ TWEAKS PANEL (host protocol) ============
(() => {
  const defaults = window.__FG_TWEAKS_DEFAULTS || { hero: "a", accent: "#A8CCEC", showWhatsApp: true, showClients: true };
  let state = { ...defaults };
  let panelEl = null;
  let active = false;

  // Apply state to DOM
  function apply() {
    document.body.setAttribute('data-hero', state.hero);
    document.documentElement.style.setProperty('--c-blue-200', state.accent);
    const wa = document.querySelector('.wa-float');
    if (wa) wa.style.display = state.showWhatsApp ? '' : 'none';
    const clients = document.querySelector('.clients-section');
    if (clients) clients.style.display = state.showClients ? '' : 'none';
  }

  // Persist + apply
  function set(k, v) {
    state[k] = v;
    apply();
    try {
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
    } catch (e) {}
    renderPanel(); // refresh control highlights
  }

  function renderPanel() {
    if (!panelEl) return;
    panelEl.innerHTML = `
      <div class="tw-head">
        <div>
          <div class="tw-eyebrow">Tweaks</div>
          <div class="tw-title">Ajustes de diseño</div>
        </div>
        <button class="tw-close" id="tw-close" aria-label="Cerrar">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>

      <div class="tw-section">
        <div class="tw-label">Estilo del Hero</div>
        <div class="tw-segmented">
          <button data-act="hero" data-val="a" class="${state.hero==='a'?'on':''}">
            <span class="tw-preview tw-preview-a"></span>
            <span>A · Cinemático</span>
          </button>
          <button data-act="hero" data-val="b" class="${state.hero==='b'?'on':''}">
            <span class="tw-preview tw-preview-b"></span>
            <span>B · Clínico</span>
          </button>
        </div>
        <div class="tw-help">A: imagen full-bleed con overlay oscuro · B: layout claro con formas celestes</div>
      </div>

      <div class="tw-section">
        <div class="tw-label">Color de acento (celeste)</div>
        <div class="tw-swatches">
          ${['#A8CCEC','#7AB4E0','#5FA0D8','#B8DCE8'].map(c =>
            `<button data-act="accent" data-val="${c}" class="tw-swatch ${state.accent===c?'on':''}" style="background:${c}" title="${c}"></button>`
          ).join('')}
        </div>
      </div>

      <div class="tw-section">
        <div class="tw-label">Secciones opcionales</div>
        <label class="tw-toggle">
          <input type="checkbox" data-act="showClients" ${state.showClients?'checked':''}>
          <span class="tw-track"></span>
          <span>Sección de clientes / hospitales</span>
        </label>
        <label class="tw-toggle">
          <input type="checkbox" data-act="showWhatsApp" ${state.showWhatsApp?'checked':''}>
          <span class="tw-track"></span>
          <span>Botón flotante de WhatsApp</span>
        </label>
      </div>

      <div class="tw-foot">
        <span>Los cambios se guardan automáticamente.</span>
      </div>
    `;

    panelEl.querySelector('#tw-close').addEventListener('click', dismiss);
    panelEl.querySelectorAll('[data-act="hero"]').forEach(b =>
      b.addEventListener('click', () => set('hero', b.dataset.val))
    );
    panelEl.querySelectorAll('[data-act="accent"]').forEach(b =>
      b.addEventListener('click', () => set('accent', b.dataset.val))
    );
    panelEl.querySelectorAll('input[data-act]').forEach(inp =>
      inp.addEventListener('change', () => set(inp.dataset.act, inp.checked))
    );
  }

  function showPanel() {
    if (active) return;
    active = true;
    panelEl = document.createElement('div');
    panelEl.className = 'tw-panel';
    document.body.appendChild(panelEl);
    renderPanel();
    requestAnimationFrame(() => panelEl.classList.add('in'));
  }

  function hidePanel() {
    if (!active) return;
    active = false;
    if (panelEl) {
      panelEl.classList.remove('in');
      setTimeout(() => { if (panelEl) panelEl.remove(); panelEl = null; }, 240);
    }
  }

  function dismiss() {
    hidePanel();
    try {
      window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
    } catch (e) {}
  }

  // Inject styles
  const css = document.createElement('style');
  css.textContent = `
    .tw-panel {
      position: fixed;
      bottom: 24px; right: 24px;
      z-index: 100;
      width: 320px;
      max-width: calc(100vw - 32px);
      background: rgba(255,255,255,0.97);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(11,31,63,0.08);
      border-radius: 18px;
      box-shadow: 0 12px 24px rgba(11,31,63,0.08), 0 30px 70px rgba(11,31,63,0.18);
      padding: 22px;
      font-family: var(--ff);
      color: var(--c-ink-900);
      transform: translateY(16px); opacity: 0;
      transition: opacity .2s ease, transform .25s ease;
    }
    .tw-panel.in { opacity: 1; transform: none; }
    .tw-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; margin-bottom: 20px; }
    .tw-eyebrow { font-size: 11px; letter-spacing: 0.16em; text-transform: uppercase; color: var(--c-navy-700); font-weight: 600; }
    .tw-title { font-size: 16px; font-weight: 600; letter-spacing: -0.01em; margin-top: 4px; }
    .tw-close {
      width: 32px; height: 32px;
      display: grid; place-items: center;
      background: var(--c-silver); border: none; border-radius: 8px;
      cursor: pointer; color: var(--c-ink-700);
      transition: background .15s ease;
    }
    .tw-close:hover { background: var(--c-line); }
    .tw-section { margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid var(--c-line); }
    .tw-section:last-of-type { border-bottom: none; padding-bottom: 0; margin-bottom: 16px; }
    .tw-label { font-size: 12px; font-weight: 600; letter-spacing: 0.02em; color: var(--c-ink-700); margin-bottom: 12px; }
    .tw-help { font-size: 11px; color: var(--c-ink-500); margin-top: 10px; line-height: 1.4; }
    .tw-segmented { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .tw-segmented button {
      display: flex; flex-direction: column; align-items: stretch; gap: 8px;
      padding: 10px;
      background: #fff;
      border: 1px solid var(--c-line);
      border-radius: 10px;
      cursor: pointer;
      font-family: var(--ff);
      font-size: 12px; font-weight: 500;
      color: var(--c-ink-700);
      text-align: left;
      transition: all .15s ease;
    }
    .tw-segmented button.on { border-color: var(--c-navy-700); background: var(--c-silver); color: var(--c-navy-700); font-weight: 600; }
    .tw-segmented button:hover { border-color: var(--c-navy-700); }
    .tw-preview { width: 100%; height: 36px; border-radius: 6px; display: block; }
    .tw-preview-a {
      background: linear-gradient(135deg, #1A3A6B 0%, #0B1F3F 100%);
      position: relative;
    }
    .tw-preview-a::after {
      content: ""; position: absolute; left: 6px; top: 50%; transform: translateY(-50%);
      width: 60%; height: 4px; background: rgba(255,255,255,0.7); border-radius: 2px;
    }
    .tw-preview-b {
      background: #fff;
      border: 1px solid var(--c-line);
      position: relative; overflow: hidden;
    }
    .tw-preview-b::before {
      content: ""; position: absolute; top: -10px; right: -10px;
      width: 24px; height: 24px; border-radius: 50%;
      background: var(--c-blue-200); opacity: 0.6;
    }
    .tw-preview-b::after {
      content: ""; position: absolute; left: 6px; top: 50%; transform: translateY(-50%);
      width: 50%; height: 4px; background: var(--c-navy-700); border-radius: 2px;
    }
    .tw-swatches { display: flex; gap: 8px; }
    .tw-swatch {
      width: 36px; height: 36px;
      border-radius: 10px;
      border: 2px solid transparent;
      cursor: pointer;
      transition: border-color .15s ease, transform .15s ease;
    }
    .tw-swatch.on { border-color: var(--c-navy-700); transform: scale(1.05); }
    .tw-swatch:hover { transform: scale(1.05); }
    .tw-toggle {
      display: flex; align-items: center; gap: 12px;
      font-size: 13px; padding: 8px 0;
      cursor: pointer; color: var(--c-ink-700);
    }
    .tw-toggle input { display: none; }
    .tw-track {
      width: 36px; height: 20px;
      background: var(--c-line);
      border-radius: 999px;
      position: relative;
      transition: background .2s ease;
      flex-shrink: 0;
    }
    .tw-track::after {
      content: "";
      position: absolute;
      width: 16px; height: 16px;
      border-radius: 50%;
      background: #fff;
      top: 2px; left: 2px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.2);
      transition: transform .2s ease;
    }
    .tw-toggle input:checked + .tw-track { background: var(--c-navy-700); }
    .tw-toggle input:checked + .tw-track::after { transform: translateX(16px); }
    .tw-foot { font-size: 11px; color: var(--c-ink-500); text-align: center; padding-top: 8px; }
  `;
  document.head.appendChild(css);

  // Apply initial state
  apply();

  // Listen for activation
  window.addEventListener('message', (e) => {
    if (!e.data || typeof e.data !== 'object') return;
    if (e.data.type === '__activate_edit_mode') showPanel();
    if (e.data.type === '__deactivate_edit_mode') hidePanel();
  });

  // Announce availability
  try {
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
  } catch (e) {}
})();
